#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void *func1(void *arg)
{

    printf("Inside the first thread\n");
    pthread_t id = pthread_self();
    printf("first thread id %lu\n", (unsigned long)id);
    printf("exiting first thread id %lu\n", (unsigned long)id);
    pthread_exit(NULL);
}

void *func2(void *arg)
{

    printf("Inside the second thread\n");
    pthread_t id = pthread_self();
    printf("second thread id %lu\n", (unsigned long)id);
    printf("exiting second thread id %lu\n", (unsigned long)id);
    pthread_exit(NULL);
}
void *func3(void *arg)
{

    printf("Inside the third thread\n");
    pthread_t id = pthread_self();
    printf("third thread id %lu\n", (unsigned long)id);
    printf("exiting third thread id %lu\n", (unsigned long)id);
    pthread_exit(NULL);
}
void *func4(void *arg)
{

    printf("Inside the forth thread\n");
    pthread_t id = pthread_self();
    printf("forth thread id %lu\n", (unsigned long)id);
    printf("exiting forth thread id %lu\n", (unsigned long)id);
    pthread_exit(NULL);
}

// Driver code
int main()
{
    pthread_t ptid1;
    pthread_t ptid2;
    pthread_t ptid3;
    pthread_t ptid4;
    pthread_attr_t attr;
    pthread_attr_setschedpolicy(&attr, SCHED_OTHER);
    clock_t start, end;
    double cpu_time_used;
    start = clock();
    // Creating a new thread
    pthread_create(&ptid1, NULL, &func1, NULL);
    pthread_create(&ptid2, NULL, &func2, NULL);
    pthread_create(&ptid3, NULL, &func3, NULL);
    pthread_create(&ptid4, NULL, &func4, NULL);
    printf("This line may be printed before thread terminates\n");

    // Compare the two threads created
    if (pthread_equal(ptid1, pthread_self()))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");
    if (pthread_equal(ptid2, pthread_self()))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");
    if (pthread_equal(ptid3, pthread_self()))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");
    if (pthread_equal(ptid4, pthread_self()))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");
    if (pthread_equal(ptid1, ptid2))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");
    if (pthread_equal(ptid1, ptid3))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");
    if (pthread_equal(ptid2, ptid3))
        printf("Threads are equal\n");
    else
        printf("Threads are not equal\n");

    // Waiting for the created thread to terminate
    pthread_join(ptid1, NULL);
    pthread_join(ptid2, NULL);
    pthread_join(ptid3, NULL);
    pthread_join(ptid4, NULL);

    printf("This line will be printed after thread ends\n");
    end = clock() - start;
    cpu_time_used = ((double)end) / CLOCKS_PER_SEC;
    printf("%i\n", end);
    printf("%.4f\n", cpu_time_used);
    pthread_exit(NULL);
    return 0;
}